from BD.conexion import DAO
import funciones


def menuPrincipal():
    continuar = True
    while(continuar):
        opcionCorrecta = False
        while(not opcionCorrecta):
            print("==================== MENÚ PRINCIPAL ====================")
            print("1.- Listar clientes")
            print("2.- Registrar cliente")
            print("3.- Actualizar cliente")
            print("4.- Eliminar cliente")
            print("5.- Salir")
            print("========================================================")
            opcion = int(input("Seleccione una opción: "))

            if opcion < 1 or opcion > 5:
                print("Opción incorrecta, ingrese nuevamente...")
            elif opcion == 5:
                continuar = False
                print("¡Gracias por usar este sistema!")
                break
            else:
                opcionCorrecta = True
                ejecutarOpcion(opcion)


def ejecutarOpcion(opcion):
    dao = DAO()

    if opcion == 1:
        try:
            clientes = dao.listarClientes()
            if len(clientes) > 0:
                funciones.listarClientes(clientes)
            else:
                print("No se encontraron clientes...")
        except:
            print("Ocurrió un error...")
    elif opcion == 2:
        clientes = funciones.pedirDatosRegistro()
        try:
            dao.registrarClientes(clientes)
        except:
            print("Ocurrió un error...")
    elif opcion == 3:
        try:
            clientes = dao.listarClientes()
            if len(clientes) > 0:
                clientes = funciones.pedirDatosActualizacion(clientes)
                if clientes:
                    dao.actualizarClientes(clientes)
                else:
                    print("id del ciente a actualizar no fue encontrado...\n")
            else:
                print("No se encontraron clientes...")
        except:
            print("Ocurrió un error...")
    elif opcion == 4:
        try:
            cursos = dao.listarClientes()
            if len(clientes) > 0:
                idClienteEliminar = funciones.pedirDatosEliminacion(cursos)
                if not(idClienteEliminar == ""):
                    dao.eliminarCliente(idClienteEliminar)
                else:
                    print("id del cliente no fue encontrado...\n")
            else:
                print("No se encontraron clientes...")
        except:
            print("Ocurrió un error...")
    else:
        print("Opción no válida...")


menuPrincipal()
