import mysql.connector
from mysql.connector import Error


class DAO():

    def __init__(self):
        try:
            self.conexion = mysql.connector.connect(
                host='localhost',
                port=3306,
                user='root',
                password='',
                db='cliente_plazajengibre'
            )
        except Error as ex:
            print("Error al intentar la conexión: {0}".format(ex))

    def listarClientes(self):
        if self.conexion.is_connected():
            try:
                cursor = self.conexion.cursor()
                cursor.execute("SELECT * FROM clientes ORDER BY nombre ASC")
                resultados = cursor.fetchall()
                return resultados
            except Error as ex:
                print("Error al intentar la conexión: {0}".format(ex))

    def registrarClientes(self, clientes):
        if self.conexion.is_connected():
            try:
                cursor = self.conexion.cursor()
                sql = "INSERT INTO clientes (idCliente, nombresCliente, telefonocliente) VALUES ('{0}', '{1}', {2})"
                cursor.execute(sql.format(clientes[0], clientes[1], clientes[2]))
                self.conexion.commit()
                print("¡Cliente registrado!\n")
            except Error as ex:
                print("Error al intentar la conexión: {0}".format(ex))

    def actualizarClientes(self, clientes):
        if self.conexion.is_connected():
            try:
                cursor = self.conexion.cursor()
                sql = "UPDATE clientes SET nombresCliente = '{0}', telefonocliente = {1}  WHERE codigo = '{2}'"
                cursor.execute(sql.format(clientes[1], clientes[2], clientes[0]))
                self.conexion.commit()
                print("¡Cliente actualizado!\n")
            except Error as ex:
                print("Error al intentar la conexión: {0}".format(ex))

    def eliminarCliente(self, idClienteEliminar):
        if self.conexion.is_connected():
            try:
                cursor = self.conexion.cursor()
                sql = "DELETE FROM curso WHERE codigo = '{0}'"
                cursor.execute(sql.format(idClienteEliminar))
                self.conexion.commit()
                print("¡Cliente eliminado!\n")
            except Error as ex:
                print("Error al intentar la conexión: {0}".format(ex))
