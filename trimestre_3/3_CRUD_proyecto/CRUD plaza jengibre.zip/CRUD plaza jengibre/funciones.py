def listarClientes(clientes):
    print("\nClientes: \n")
    contador = 1
    for client in clientes:
        datos = "{0}. idCliente: {1} | Nombres del cliente: {2} | telefono del cliente: {3}"
        print(datos.format(contador, client[0], client[1], client[2]))
        contador = contador + 1
    print(" ")


def pedirDatosRegistro():
    idCorrecto = False
    while(not idCorrecto):
        idCliente = input("Ingrese idCliente: ")
        if len(idCliente) == 10:
            idCorrecto = True
        else:
            print("id incorrecto: Debe tener 10 dígitos.")

    nombresCliente = input("Ingrese los nombres del cliente: ")

    
    telefonoCorrecto = False
    while(not telefonoCorrecto):
        telefonoCliente = input("Ingrese # de telefono: ")
        if telefonoCliente.isnumeric():
            if (int(telefonoCliente) > 0):
                telefonoCorrecto = True
                telefonoCliente = int(telefonoCliente)
            else:
                print("el numero de telefono debe tener 10 numeros")
        else:
            print("Telefono incorrectos: Deben ser 10 numeros únicamente.")

    clientes = (idCliente, nombresCliente)
    return clientes

def pedirDatosActualizacion(clientes):
    listarClientes(clientes)
    existeidCliente = False
    idClienteEditar = input("Ingrese el id del cliente a editar: ")
    for client in clientes:
        if client[0] == idClienteEditar:
            existeidCliente = True
            break

    if existeidCliente:
        nombresCliente = input("Ingrese el nombre del ciente a modificar: ")

        telefonoCorrecto = False
        while(not telefonoCorrecto):
            telefonoCliente = input("Ingrese telefono a modificar: ")
            if telefonoCliente.isnumeric():
                if (int(telefonoCliente) > 0):
                    telefonoCorrecto = True
                    telefonoCliente = int(telefonoCliente)
                else:
                    print("El # de telefono debe tener 10 numeros.")
            else:
                print("Telefono incorrecto: Debe tener 10 números únicamente.")

        clientes = (idClienteEditar, nombresCliente, telefonoCliente)
    else:
        clientes = None

    return clientes


def pedirDatosEliminacion(clientes):
    listarClientes(clientes)
    existeidCliente= False
    idClienteEliminar = input("Ingrese el código del curso a eliminar: ")
    for client in clientes:
        if client[0] == idClienteEliminar:
            existeidCliente = True
            break

    if not existeidCliente:
        idClienteEliminar = ""

    return idClienteEliminar